//
//  ViewController.swift
//  Assignment
//
//  Created by Inno on 26/06/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

